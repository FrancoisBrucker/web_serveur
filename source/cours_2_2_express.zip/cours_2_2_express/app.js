var express = require('express')
var app = express()

app.use(function (req, res, next) {
    console.log('Time:', Date.now());
    next(); // sans cette ligne on ne pourra pas poursuivre.
})

app.use(function (req, res, next) {
    console.log("ensuite");
    next(); // sans cette ligne on ne pourra pas poursuivre.
})

app.set('view engine', 'ejs')

app.use("/static", express.static(__dirname + '/static'))

app.get('/', (request, response) => {
        response.render("index")
})

app.get('/contact', (request, response) => {
    response.render("contact")
})

app.use(function (req, res, next) {
    res.status(404).render("404")
})

app.listen(3000);
console.log("c'est parti")