var express = require('express')
var app = express()

app.set('view engine', 'ejs')


app.use("/static", express.static(__dirname + '/assets'))


app.get('/', (request, response) => {
    response.render("home")
})

app.get('/commentaires', (request, response) => {
    response.render("commentaires")
})


// 404 aucune interception
app.use(function (req, res, next) {
    res.status(404).render("404")
})


module.exports = app