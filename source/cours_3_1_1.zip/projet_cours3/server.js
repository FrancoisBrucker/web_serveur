app = require('./app.js')

port = 8080
app.listen(port);
console.log("c'est parti: http://localhost:" + port.toString())