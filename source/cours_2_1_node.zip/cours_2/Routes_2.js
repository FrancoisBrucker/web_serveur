const http = require('http')
const fs = require('fs')

var server = http.createServer((request, response) =>{
    // http://www.ecma-international.org/ecma-262/5.1/#sec-11.9.3
    response.statusCode = 200;
    response.setHeader('Content-Type', 'text/html');

    if (request.url === "/" || request.url === "/home") {
        fs.createReadStream(__dirname + "/html/index.html", "utf8").pipe(response)
    }
    else if (request.url === "/contact") {
        fs.createReadStream(__dirname + "/html/contact.html", "utf8").pipe(response)
    }
    else {
        response.statusCode = 404;
        fs.createReadStream(__dirname + "/html/404.html", "utf8").pipe(response)
    }
})

function affiche_bloup() {
    console.log("bloup")
}

affiche_bloup()

var x = affiche_bloup //affectation de la fonction à une variable

x() //exécution de la variable, donc de la fonction.



//fonction sans nom assignée à une variable
var affiche_2 = function() { // On utilisera surtout celle là.
    console.log("bloup 2")
}

affiche_2()

// tout est asyncrone.
// Lorsque la condition est vérifiée on exécute une fonction.
var timer1 = setInterval( affiche_bloup, 1000) // un intervalle

var timer2 = setInterval(function() { // un deuxième avec une function anonyme
    console.log("bim")
}, 2000)

// ---- Scopes de variables ----

var delta_1 = 0  // ces variables vont être utilisées autre part.
var delta_2 = 0  // un peu comme une variable "globale" (attention au scope)

setInterval(() => {  // encore une autre façon d'écrire une fonction
    if (delta_1 == 3) {  // mieux vaut supprimer le timer dans le timer considéré.
        clearInterval(timer1)
        delta_1 += 1
    }
    else {
        delta_1 += 1
    }

    if (delta_2 == 10) {
        clearInterval(timer2)
        delta_2 += 1
    }
    else {
        delta_2 += 1
    }

}, 1000)

// ---- Scopes de variables ----

// ---- Modules ----

// importe le module, c'est à dire que l'on rend l'objet module.exports
// il est ensuite placé dans une variable, ici monModule
var monModule = require("./un_module");

monModule.klaxon()

console.log(monModule.reponse)
        
// ---- Modules ----

server.listen(3000, 'localhost')
console.log("c'est parti")