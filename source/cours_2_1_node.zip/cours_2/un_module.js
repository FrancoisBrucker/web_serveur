//module.exports est un objet rendu par require.
// on lui donne donc comme attribut, les méthodes et constante que l'on veut voir transmise.

module.exports.klaxon = function() {
    console.log("tuuuut !");
}


module.exports.reponse = 42