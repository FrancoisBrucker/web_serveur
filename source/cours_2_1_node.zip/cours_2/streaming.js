var http = require('http')

// le streaming permet de commencer à envoyer des données alors que le fichier n'est pas fini.
//exemple avec un gros fichier.

var server = http.createServer((request, response) => {
    response.statusCode = 200;
            response.setHeader('Content-Type', 'text/plain');

    // stream : chargement par paquets.
    http.get("http://www.gutenberg.org/files/4300/4300-0.txt", (response_get) => {
        response_get.setEncoding('utf8');
        response_get.pipe(response)
    });

})


server.listen(3000, 'localhost')
console.log("c'est parti")